<?php
	if (isset($_REQUEST['nom']) && isset($_REQUEST['lat'])&& isset($_REQUEST['lon'])) {
		$nom = $_REQUEST['nom'];
		$lat = $_REQUEST['lat'];
		$lon = $_REQUEST['lon'];
		
		// include db handler
		require_once './db/DB_Functions.php';
		$db = new DB_Functions();
		$db->ajouterGouv($nom, $lat,$lon);
		$reponse=array();
		$reponse["ETAT"]="SUCCES";
		
		echo json_encode($reponse);
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}
?>