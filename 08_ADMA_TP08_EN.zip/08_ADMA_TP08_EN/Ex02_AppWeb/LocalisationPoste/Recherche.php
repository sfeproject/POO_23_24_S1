<?php
	


if ( isset($_REQUEST['nomG'])&& isset($_REQUEST['nomB'])) {
		$nomG = $_REQUEST['nomG'];
		$nomB = $_REQUEST['nomB'];
		// include db handler
		require_once './db/DB_Functions.php';
		$db = new DB_Functions();
		$db->rechercherBureau($nomG,$nomB);
		
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}	
?>	
