<?php
 
class DB_Functions {
 
    private $db;
 
    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	/**
     * Ajouter BUREAU
    */
    public function ajouterBureau($nom, $cp,$lat,$lon,$nomGouv) {
        $result = mysql_query("INSERT INTO bureau(nom,cp,lat,lon,nom_gouv) VALUES('$nom',$cp,$lat,$lon, '$nomGouv')")or die(mysql_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
		
    }
	/**
     * Ajouter GOUV
    */
    public function ajouterGouv($nom, $lat,$lon) {
        $result = mysql_query("INSERT INTO gouv(nom,lat,lon) VALUES('$nom',$lat,$lon)")or die(mysql_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
		
    }
	 /**
     * Get Gouv
	 */
    public function listeGouv() {
		$result = mysql_query("SELECT * FROM gouv Order By nom Asc;")or die(mysql_error());
		$aPh=array();
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$ph=array();
			$ph["id"]=$row['id'];
			$ph["nom"]=$row['nom'];
			$ph["lat"]=$row['lat'];
			$ph["lon"]=$row['lon'];
			$aPh[]=$ph;
			$reponse=array();
			$reponse["gouvs"]=$aPh;
		}
		echo json_encode($reponse);
		mysql_free_result($result);
    }
   /**
     * Get Livre
    */
    public function rechercherBureau($nomG,$nomB) {
		$result = mysql_query("SELECT * FROM bureau where nom like '%$nomB%' AND nom_gouv='$nomG' Order By nom Asc;")or die(mysql_error());
		$aPh=array();
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			$ph=array();
			$ph["id"]=$row['id'];
			$ph["nom"]=$row['nom'];
			$ph["cp"]=$row['cp'];
			$ph["lat"]=$row['lat'];
			$ph["lon"]=$row['lon'];			
			$aPh[]=$ph;
			$reponse=array();
			$reponse["bureaux"]=$aPh;
		}
		echo json_encode($reponse);
		mysql_free_result($result);
    }
	
	public function close() {
		$this->db->close();
	}
}
 
?>