package radio.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class RechercheBureau extends AppCompatActivity {
    private Spinner spGouv;
    private EditText edNom;
    private Button btnRechercher;
    private ArrayAdapter<String> adpGouv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche_bureau);
        init();
    }

    private void init() {
        spGouv=findViewById(R.id.spGouv);
        edNom=findViewById(R.id.edNom);
        btnRechercher=findViewById(R.id.btnRechercher);
        adpGouv=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item);
        spGouv.setAdapter(adpGouv);
        ajouterEcouteur();
        remplir();
    }

    private void ajouterEcouteur() {
        btnRechercher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rechercher();
            }
        });
    }

    private void remplir() {
    }

    private void rechercher() {
    }


}
